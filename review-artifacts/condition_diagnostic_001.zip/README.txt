﻿DoR condition-field diagnostic package
Contains bounded field inventory, field types and truncated examples.
Does not contain the original database, PDFs or full paper text.

﻿DoR condition evidence diagnostic v2
Contains bounded target_system summaries, batch distribution,
worker evidence key inventories, and truncated evidence samples.
Does not contain the original database or full papers.
